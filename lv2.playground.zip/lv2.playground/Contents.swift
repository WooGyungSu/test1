import UIKit
class Calculator {
    func calculator (operator: String, firstNumber: Int, secondNumber: Int) -> Double? {
        if `operator` == "+" {
            return Double(firstNumber + secondNumber)
        }
        if `operator` == "-" {
            return Double(firstNumber - secondNumber)
        }
        if `operator` == "*" {
            return Double(firstNumber * secondNumber)
        }
        if `operator` == "/" {
            return Double(firstNumber / secondNumber)
        }
        if `operator` == "%" {
            return Double(firstNumber % secondNumber)
        }
        
        return nil
    }
}
    
let calculator = Calculator()
let addResult = calculator.calculator(operator: "+", firstNumber: 10, secondNumber: 20)!
let subtractResult = calculator.calculator(operator: "-", firstNumber: 30, secondNumber: 20)!
let multiplyResult = calculator.calculator(operator: "*", firstNumber: 10, secondNumber: 5)!
let divideResult = calculator.calculator(operator: "/", firstNumber: 40, secondNumber: 10)!
let remainderResult = calculator.calculator(operator: "%", firstNumber: 8, secondNumber: 3)!


    
print("addResult : \(addResult)")
print("subtractResult : \(subtractResult)")
print("multiplyResult : \(multiplyResult)")
print("divideResult : \(divideResult)")
print("remainderResult : \(remainderResult)")
