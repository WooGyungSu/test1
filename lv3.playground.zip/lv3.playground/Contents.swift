import UIKit
class AddOperation {
    func operate(firstNumber: Int, secondNumber: Int) ->Double? {
        return Double(firstNumber + secondNumber)
    }
}
class SubtractOperation {
    func operate(firstNumber: Int, secondNumber: Int) -> Double {
        return Double(firstNumber - secondNumber)
    }
}
class MultiplyOperation {
    func operate(firstName: Int, secondName: Int) -> Double {
        return Double(firstName * secondName)
    }
}
class DivideOperation {
    func operate(firstName: Int, secondName: Int) -> Double {
        return Double(firstName / secondName)
    }
}
class Calculator {
    private let addOperation: AddOperation
    private let subtractOperation: SubtractOperation
    private let multiplyOperation: MultiplyOperation
    private let divideOperation: DivideOperation
    
    init(addOperation: AddOperation, subtractOperation: SubtractOperation, multiplyOperation: MultiplyOperation, divideOperation: DivideOperation) {
        self.addOperation = addOperation
        self.subtractOperation = subtractOperation
        self.multiplyOperation = multiplyOperation
        self.divideOperation = divideOperation
    }
    
    func calculate(operation: String, firstNumber: Int, secondNumber: Int) -> Double? {
        if `operation` == "+" {
            return addOperation.operate(firstNumber: firstNumber, secondNumber: secondNumber)
        }
        if `operation` == "-" {
            return subtractOperation.operate(firstNumber: firstNumber, secondNumber: secondNumber)
        }
        if `operation` == "*" {
            return multiplyOperation.operate(firstName: firstNumber, secondName: secondNumber)
        }
        if `operation` == "/" {
            return divideOperation.operate(firstName: firstNumber, secondName: secondNumber)
        }
        return nil
    }
}
let calculator = Calculator(
addOperation: AddOperation(), subtractOperation: SubtractOperation(), multiplyOperation: MultiplyOperation(), divideOperation: DivideOperation()
)


//
let addResult = calculator.calculate(operation: "+", firstNumber: 20, secondNumber: 10) ?? 0
let subtractOperation = calculator.calculate(operation: "-", firstNumber: 30, secondNumber: 10) ?? 0
let multiplyOperation = calculator.calculate(operation: "*", firstNumber: 5, secondNumber: 4) ?? 0
let divideOperation = calculator.calculate(operation: "/", firstNumber: 30, secondNumber: 2) ?? 0



print("addResult: \(addResult)")
print("subtractOperation : \(subtractOperation)")
print("multiplyOperation : \(multiplyOperation)")
print("divideOperation : \(divideOperation)")
