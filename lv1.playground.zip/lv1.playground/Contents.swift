import UIKit
class Calculator {
    func calculate(operator: String, firstNumber: Int, secondNumber: Int) -> Double? {
        if `operator` == "+" {
            return Double(firstNumber + secondNumber)
        }
        if `operator` == "-" {
            return Double(firstNumber - secondNumber)
        }
        if `operator` == "*" {
            return Double(firstNumber * secondNumber)
        }
        if `operator` == "/" {
            return Double(firstNumber / secondNumber)
        }
        
        return nil
        
    }
}
    
let calculator = Calculator()
if let addResult = calculator.calculate(operator: "+", firstNumber: 20, secondNumber: 10) {
    print("addResult : \(addResult)")
}
if let subtractResult = calculator.calculate(operator: "-", firstNumber: 30, secondNumber: 10) {
    print("subtractResult : \(subtractResult)")
}
if let multiplyResult = calculator.calculate(operator: "*", firstNumber: 5, secondNumber: 10) {
    print("multiplyResult : \(multiplyResult)")
}
if let divideResult = calculator.calculate(operator: "/", firstNumber: 10, secondNumber: 2) {
    print("divideResult : \(divideResult)")
}
    
