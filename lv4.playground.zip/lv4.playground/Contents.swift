import UIKit
class AbstractOperation {
    func operate(firstNumber: Int, secondNumber: Int) -> Double? {
        return nil
    }
}
class AddOperation: AbstractOperation {
    override func operate(firstNumber: Int, secondNumber: Int) -> Double? {
        return Double(firstNumber + secondNumber)
    }
}
class SubtractOperation: AbstractOperation {
    override func operate(firstNumber: Int, secondNumber: Int) -> Double? {
        return Double(firstNumber - secondNumber)
    }
}
class MultiplyOperation : AbstractOperation {
    override func operate(firstNumber: Int, secondNumber: Int) -> Double? {
        return Double(firstNumber * secondNumber)
    }
}
class DivideOperation: AbstractOperation {
    override func operate(firstNumber: Int, secondNumber: Int) -> Double? {
        return Double(firstNumber / secondNumber)
    }
}
class Calculator {
    private var abstractOperation: AbstractOperation
    
    init(operation: AbstractOperation) {
        self.abstractOperation = operation
    }
    
    func setOperation(operation: AbstractOperation) {
        self.abstractOperation = operation
    }
    
    func calculate(firstNumber: Int, secondNumber: Int) -> Double {
        abstractOperation.operate(firstNumber: firstNumber, secondNumber: secondNumber) ?? 0
    }
}

let calculator = Calculator(operation: AddOperation())

let addResult = calculator.calculate(firstNumber: 10, secondNumber: 20)

calculator.setOperation(operation: SubtractOperation())
let subtractResult = calculator.calculate(firstNumber: 20, secondNumber: 5)

calculator.setOperation(operation: MultiplyOperation())
let multiplyResult = calculator.calculate(firstNumber: 5, secondNumber: 2)

calculator.setOperation(operation: DivideOperation())
let divideResult = calculator.calculate(firstNumber: 10, secondNumber: 2)

print("addResult : \(addResult)")
print("subtractResult \(subtractResult)")
print("multiplyResult : \(multiplyResult)")
print("divideResult : \(divideResult)")
